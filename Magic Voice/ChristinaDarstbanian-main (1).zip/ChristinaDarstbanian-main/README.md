# ilink-hachathon-shadi-christina

## Backend

    - PHP Laravel
    - MySQL Database

    - HTML, CSS, Javascript (with blade template)

    - Login View
    - Register View
    - Index View
